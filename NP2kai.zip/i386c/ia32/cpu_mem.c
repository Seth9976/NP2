﻿/*
 * Copyright (c) 2002-2004 NONAKA Kimihiro
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <compiler.h>
#include "cpu.h"
#include "cpumem.h"


/*
 * memory access check
 */
static int MEMCALL check_limit_upstairs(descriptor_t *sdp, UINT32 offset, UINT len, BOOL is32bit);
static void MEMCALL cpu_memoryread_check(descriptor_t *sdp, UINT32 offset, UINT len, int e);
static void MEMCALL cpu_memorywrite_check(descriptor_t *sdp, UINT32 offset, UINT len, int e);

static int MEMCALL
check_limit_upstairs(descriptor_t *sdp, UINT32 offset, UINT len, BOOL is32bit)
{
	UINT32 limit;
	UINT32 end;

	__ASSERT(sdp != NULL);
	__ASSERT(len > 0);

	len--;
	end = offset + len;

	if (SEG_IS_DATA(sdp) && SEG_IS_EXPANDDOWN_DATA(sdp)) {
		/* expand-down data segment */
		limit = is32bit ? 0xffffffff : 0x0000ffff;

		if (sdp->u.seg.limit >= limit) {
			goto exc; // 16bit範囲を超えていたら全範囲無効
		}

		if (sdp->u.seg.limit == 0) {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |       |   |       |
			 * |       |   +  [1]  + 0000FFFFh
			 * | valid |   |       |
			 * |       |   +-------+ 0000FFFFh - len -1
			 * |       |   | valid |
			 * +-------+   +-------+ 00000000h
			 * Expand-down segments start at limit + 1.  Therefore
			 * offset 0 is not valid even when the descriptor limit is 0.
			 */
			if ((len > limit)			/* len check */
			 || (end < offset)			/* wrap check */
			 || (offset == 0)			/* lower bound */
			 || (end > limit)) {			/* upper bound */
				goto exc;
			}
		} else {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |  [2]  |   |       |
			 * +-------+   +.......+ FFFFFFFFh - len - 1
			 * |       |   |  [2]  |
			 * |       |   +.......+ 0000FFFFh
			 * | valid |   |       |
			 * |       |   +-------+ 0000FFFFh - len - 1
			 * |       |   | valid |
			 * +-------+   +-------+ seg.limit
			 * |  [1]  |   |  [1]  |
			 * +-------+   +-------+ 00000000h
			 */
			if ((len > limit - sdp->u.seg.limit)	/* len check */
			 || (end < offset)			/* wrap check */
			 || (offset <= sdp->u.seg.limit)	/* [1] */
			 || (end > limit)) {			/* [2] */
				goto exc;
			}
		}
	} else {
		/* expand-up data or code segment */
		if (sdp->u.seg.limit == 0xffffffff) {
			/*
			 *  16/32bit
			 * +-------+ FFFFFFFFh
			 * |       |
			 * |       |
			 * | valid |
			 * |       |
			 * |       |
			 * +-------+ 00000000h
			 */
			sdp->flag |= CPU_DESC_FLAG_WHOLEADR;
		} else {
			/*
			 *  16/32bit
			 * +-------+ FFFFFFFFh
			 * |       |
			 * |       |
			 * |  [1]  |
			 * +.......+ seg.limit
			 * |       |
			 * +-------+ seg.limit - len - 1
			 * | valid |
			 * +-------+ 00000000h
			 */
			if ((len > sdp->u.seg.limit)		/* len check */
			 || (end < offset)			/* wrap check */
			 || (end > sdp->u.seg.limit)) {		/* [1] */
				goto exc;
			}
		}
	}
	return 1;	/* Ok! */

exc:
	VERBOSE(("check_limit_upstairs: check failure: offset = 0x%08x, len = %d", offset, len + 1));
#if defined(DEBUG)
	segdesc_dump(sdp);
#endif
	return 0;
}

static void MEMCALL
cpu_memoryread_check(descriptor_t *sdp, UINT32 offset, UINT len, int e)
{

	__ASSERT(sdp != NULL);
	__ASSERT(len > 0);

	if (!SEG_IS_VALID(sdp)) {
		e = GP_EXCEPTION;
		goto exc;
	}
	if (!SEG_IS_PRESENT(sdp)
	 || SEG_IS_SYSTEM(sdp)
	 || (SEG_IS_CODE(sdp) && !SEG_IS_READABLE_CODE(sdp))) {
		goto exc;
	}

	switch (sdp->type) {
	case 0:	 case 1:	/* ro */
	case 2:  case 3:	/* rw */
	case 4:  case 5:	/* ro (expand down) */
	case 6:  case 7:	/* rw (expand down) */
	case 10: case 11:	/* rx */
	case 14: case 15:	/* rxc */
		if (!check_limit_upstairs(sdp, offset, len, SEG_IS_32BIT(sdp)))
			goto exc;
		break;

	default:
		goto exc;
	}
	sdp->flag |= CPU_DESC_FLAG_READABLE;
	return;

exc:
	VERBOSE(("cpu_memoryread_check: check failure: offset = 0x%08x, len = %d", offset, len));
#if defined(DEBUG)
	segdesc_dump(sdp);
#endif
	EXCEPTION(e, 0);
}

static void MEMCALL
cpu_memorywrite_check(descriptor_t *sdp, UINT32 offset, UINT len, int e)
{

	__ASSERT(sdp != NULL);
	__ASSERT(len > 0);

	if (!SEG_IS_VALID(sdp)) {
		e = GP_EXCEPTION;
		goto exc;
	}
	if (!SEG_IS_PRESENT(sdp)
	 || SEG_IS_SYSTEM(sdp)
	 || SEG_IS_CODE(sdp)
	 || (SEG_IS_DATA(sdp) && !SEG_IS_WRITABLE_DATA(sdp))) {
		goto exc;
	}

	switch (sdp->type) {
	case 2: case 3:	/* rw */
	case 6: case 7:	/* rw (expand down) */
		if (!check_limit_upstairs(sdp, offset, len, SEG_IS_32BIT(sdp)))
			goto exc;
		break;

	default:
		goto exc;
	}
	sdp->flag |= CPU_DESC_FLAG_WRITABLE | CPU_DESC_FLAG_READABLE;
	return;

exc:
	VERBOSE(("cpu_memorywrite_check: check failure: offset = 0x%08x, len = %d", offset, len));
#if defined(DEBUG)
	segdesc_dump(sdp);
#endif
	EXCEPTION(e, 0);
}

void MEMCALL
cpu_stack_push_check(UINT16 s, descriptor_t *sdp, UINT32 sp, UINT len,
    BOOL is32bit)
{
	UINT32 limit;
	UINT32 seglimit;
	UINT32 start;

	__ASSERT(sdp != NULL);
	__ASSERT(len > 0);

	len--;

	if (!SEG_IS_VALID(sdp)
	 || !SEG_IS_PRESENT(sdp)
	 || SEG_IS_SYSTEM(sdp)
	 || SEG_IS_CODE(sdp)
	 || !SEG_IS_WRITABLE_DATA(sdp)) {
		goto exc;
	}

	//start = sp - len;
	//limit = is32bit ? 0xffffffff : 0x0000ffff;
	limit = is32bit ? 0xffffffff : 0x0000ffff;
	sp = (sp - 1) & limit;
	start = (sp - len) & limit;


	if (SEG_IS_EXPANDDOWN_DATA(sdp)) {
		/* expand-down stack */
		if (!SEG_IS_32BIT(sdp)) {
			if (sp > limit) {			/* [*] */
				goto exc;
			}
		}

		if (sdp->u.seg.limit >= limit) {
			goto exc; // 16bit範囲を超えていたら全範囲無効
		}

		if (sdp->u.seg.limit == 0) {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |       |   |  [*]  |
			 * |       |   +-------+ 0000FFFFh
			 * | valid |   |       |
			 * |       |   | valid |
			 * |       |   |       |
			 * +-------+   +-------+ 00000000h
			 */
			if (!SEG_IS_32BIT(sdp)) {
				if (sp > limit) {		/* [1] */
					goto exc;
				}
			} else {
				sdp->flag |= CPU_DESC_FLAG_WHOLEADR;
			}
		} else {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |       |   |  [*]  |
			 * | valid |   +-------+ 0000FFFFh
			 * |       |   | valid |
			 * +-------+   +-------+ seg.limit + len - 1
			 * |       |   |       |
			 * +..[1]..+   +..[1]..+ seg.limit
			 * |       |   |       |
			 * +-------+   +-------+ 00000000h
			 */
			if ((len > limit - sdp->u.seg.limit)	/* len check */
			 || (start > sp)			/* wrap check */
			 || (start < sdp->u.seg.limit)) {	/* [1] */
				goto exc;
			}
		}
	} else {
		/* expand-up stack */
		seglimit = sdp->u.seg.limit;
		if (seglimit > limit) {
			seglimit = limit; // 16bit範囲を超えていたら全範囲有効
		}

		if (seglimit == limit) {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |       |   |  [1]  |
			 * |       |   +-------+ 0000FFFFh
			 * | valid |   |       |
			 * |       |   | valid |
			 * |       |   |       |
			 * +-------+   +-------+ 00000000h
			 */
			if (sdp->u.seg.limit == 0xffffffff) {
				sdp->flag |= CPU_DESC_FLAG_WHOLEADR;
			}
		} else {
			/*
			 *   32bit       16bit
			 * +-------+   +-------+ FFFFFFFFh
			 * |       |   |       |
			 * |  [1]  |   +  [1]  + 0000FFFFh
			 * |       |   |       |
			 * +-------+   +-------+ seg.limit
			 * | valid |   | valid |
			 * +.......+   +.......+ len - 1
			 * |  [+]  |   |  [+]  |
			 * +-------+   +-------+ 00000000h
			 *
			 * [+]: wrap check
			 */
			if ((len > seglimit)			/* len check */
			 || (start > sp)			/* wrap check */
			 || (sp > seglimit + 1)) {		/* [1] */
				goto exc;
			}
		}
	}
	return;

exc:
	VERBOSE(("cpu_stack_push_check: check failure: selector = 0x%04x, sp = 0x%08x, len = %d", s, sp, len));
#if defined(DEBUG)
	segdesc_dump(sdp);
#endif
	EXCEPTION(SS_EXCEPTION, s & 0xfffc);
}

void MEMCALL
cpu_stack_pop_check(UINT16 s, descriptor_t *sdp, UINT32 sp, UINT len,
    BOOL is32bit)
{

	__ASSERT(sdp != NULL);
	__ASSERT(len > 0);

	if (!SEG_IS_VALID(sdp)
	 || !SEG_IS_PRESENT(sdp)
	 || SEG_IS_SYSTEM(sdp)
	 || SEG_IS_CODE(sdp)
	 || !SEG_IS_WRITABLE_DATA(sdp)) {
		goto exc;
	}

	if (!check_limit_upstairs(sdp, sp, len, is32bit))
		goto exc;
	return;

exc:
	VERBOSE(("cpu_stack_pop_check: check failure: selector = 0x%04x, sp = 0x%08x, len = %d", s, sp, len));
#if defined(DEBUG)
	segdesc_dump(sdp);
#endif
	EXCEPTION(SS_EXCEPTION, s & 0xfffc);
}


/*
 * code fetch
 */
PF_UINT8 MEMCALL
cpu_codefetch(UINT32 offset)
{
	const int ucrw = CPU_PAGE_READ_CODE | CPU_STAT_USER_MODE;
	descriptor_t *sdp;
	UINT32 addr;

	sdp = &CPU_CS_DESC;
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM)
		return cpu_memoryread_codefetch(addr);
	if (offset <= sdp->u.seg.limit)
		return cpu_lmemoryread_codefetch(addr, ucrw);

	EXCEPTION(GP_EXCEPTION, 0);
	return 0;	/* compiler happy */
}

PF_UINT16 MEMCALL
cpu_codefetch_w(UINT32 offset)
{
	const int ucrw = CPU_PAGE_READ_CODE | CPU_STAT_USER_MODE;
	descriptor_t *sdp;
	UINT32 addr;

	sdp = &CPU_CS_DESC;
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM)
		return cpu_memoryread_w_codefetch(addr);
	if (offset <= sdp->u.seg.limit - 1)
		return cpu_lmemoryread_w_codefetch(addr, ucrw);

	EXCEPTION(GP_EXCEPTION, 0);
	return 0;	/* compiler happy */
}

PF_UINT32 MEMCALL
cpu_codefetch_d(UINT32 offset)
{
	const int ucrw = CPU_PAGE_READ_CODE | CPU_STAT_USER_MODE;
	descriptor_t *sdp;
	UINT32 addr;

	sdp = &CPU_CS_DESC;
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM)
		return cpu_memoryread_d_codefetch(addr);

	if (offset <= sdp->u.seg.limit - 3)
		return cpu_lmemoryread_d_codefetch(addr, ucrw);

	EXCEPTION(GP_EXCEPTION, 0);
	return 0;	/* compiler happy */
}

#if defined(USE_CPU_MODRMPREFETCH)
PF_UINT8 MEMCALL
cpu_opcodefetch(UINT32 offset)
{
	const int ucrw = CPU_PAGE_READ_CODE | CPU_STAT_USER_MODE;
	UINT32 limit;
	UINT32 addr;
	UINT32 opcode;

	limit = CPU_CS_DESC.u.seg.limit;
	addr = CPU_CS_DESC.u.seg.segbase + offset;

	if (!CPU_STAT_PM)
	{
		return (opCache = cpu_memoryread_w_codefetch(addr)) & 0xff;
	}
	opcode = cpu_lmemoryread_w_codefetch(addr, ucrw);
	if (offset <= limit - 1)
	{
		// 2byteとも違反でない場合キャッシュする
		opCache = opcode;
		return opcode & 0xff;
	}
	else if (offset <= limit)
	{
		// 2バイト目がはみ出している場合、命令長によっては#GPなので1byteだけ読んでキャッシュはしない
		opCache = 0;
		return opcode & 0xff;
	}

	EXCEPTION(GP_EXCEPTION, 0);
	return 0;	/* compiler happy */
}
#endif

/*
 * additional physical address memory access functions
 */
UINT64 MEMCALL
cpu_memoryread_q(UINT32 paddr)
{
	UINT64 value;

	value = cpu_memoryread_d(paddr);
	value += (UINT64)cpu_memoryread_d(paddr + 4) << 32;

	return value;
}

void MEMCALL
cpu_memorywrite_q(UINT32 paddr, UINT64 value)
{

	cpu_memorywrite_d(paddr, (UINT32)value);
	cpu_memorywrite_d(paddr + 4, (UINT32)(value >> 32));
}

REG80 MEMCALL
cpu_memoryread_f(UINT32 paddr)
{
	REG80 value;
	//int i;

	//for (i = 0; i < (int)sizeof(REG80); ++i) {
	//	value.b[i] = cpu_memoryread(paddr + i);
	//}
	value.d.l[0] = cpu_memoryread_d(paddr);
	value.d.l[1] = cpu_memoryread_d(paddr + 4);
	value.d.h = cpu_memoryread_w(paddr + 8);

	return value;
}

void MEMCALL
cpu_memorywrite_f(UINT32 paddr, const REG80 *value)
{
	//int i;

	//for (i = 0; i < (int)sizeof(REG80); ++i) {
	//	cpu_memorywrite(paddr + i, value->b[i]);
	//}
	cpu_memorywrite_d(paddr, value->d.l[0]);
	cpu_memorywrite_d(paddr + 4, value->d.l[1]);
	cpu_memorywrite_w(paddr + 8, value->d.h);
}

/*
 * virtual address memory access functions
 */
#define	CHOOSE_EXCEPTION(sreg) \
	(((sreg) == CPU_SS_INDEX) ? SS_EXCEPTION : GP_EXCEPTION)

#include "cpu_mem.mcr"

static void MEMCALL
cpu_vmemorywrite_prepare_common(int idx, UINT32 offset, UINT length, UINT32 paddr[2], UINT *remain)
{
	descriptor_t *sdp;
	UINT32 addr;
	UINT first;
	int exc;

	__ASSERT((unsigned int)idx < CPU_SEGREG_NUM);
	__ASSERT(length > 0);

	sdp = &CPU_STAT_SREG(idx);
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM) {
		paddr[0] = addr;
		if (remain != NULL) {
			*remain = length;
		}
		return;
	}

	if (!SEG_IS_VALID(sdp)) {
		exc = GP_EXCEPTION;
		goto err;
	}
	if (!(sdp->flag & CPU_DESC_FLAG_WRITABLE)) {
		cpu_memorywrite_check(sdp, offset, length, CHOOSE_EXCEPTION(idx));
	} else if (!(sdp->flag & CPU_DESC_FLAG_WHOLEADR)) {
		if (!check_limit_upstairs(sdp, offset, length, SEG_IS_32BIT(sdp))) {
			goto range_failure;
		}
	}

	if (!CPU_STAT_PAGING) {
		paddr[0] = addr;
		if (remain != NULL) {
			*remain = length;
		}
		return;
	}

	first = CPU_PAGE_SIZE - (addr & CPU_PAGE_MASK);
	paddr[0] = laddr2paddr(addr, CPU_PAGE_WRITE_DATA | CPU_STAT_USER_MODE);
	if (first < length) {
		paddr[1] = laddr2paddr(addr + first, CPU_PAGE_WRITE_DATA | CPU_STAT_USER_MODE);
		if (remain != NULL) {
			*remain = first;
		}
	} else if (remain != NULL) {
		*remain = length;
	}
	return;

range_failure:
	VERBOSE(("cpu_vmemorywrite_prepare: type = %d, offset = %08x, length = %d, limit = %08x", sdp->type, offset, length, sdp->u.seg.limit));
	exc = CHOOSE_EXCEPTION(idx);
err:
	EXCEPTION(exc, 0);
}

void MEMCALL
cpu_vmemorywrite_prepare_b(int idx, UINT32 offset, UINT32 *paddr)
{
	UINT32 tmp[2];
	UINT remain;

	cpu_vmemorywrite_prepare_common(idx, offset, 1, tmp, &remain);
	*paddr = tmp[0];
}

void MEMCALL
cpu_vmemorywrite_prepare_w(int idx, UINT32 offset, UINT32 paddr[2], UINT *remain)
{
	cpu_vmemorywrite_prepare_common(idx, offset, 2, paddr, remain);
}

void MEMCALL
cpu_vmemorywrite_prepare_d(int idx, UINT32 offset, UINT32 paddr[2], UINT *remain)
{
	cpu_vmemorywrite_prepare_common(idx, offset, 4, paddr, remain);
}
void MEMCALL
cpu_vmemorywrite_commit_w(UINT32 paddr[2], UINT remain, UINT16 data)
{
	if (remain >= 2) {
		cpu_memorywrite_w(paddr[0], data);
	}
	else {
		cpu_memorywrite(paddr[0], (UINT8)data);
		cpu_memorywrite(paddr[1], (UINT8)(data >> 8));
	}
}
void MEMCALL
cpu_vmemorywrite_commit_d(UINT32 paddr[2], UINT remain, UINT32 data)
{
	switch (remain) {
	case 1:
		cpu_memorywrite(paddr[0], (UINT8)data);
		cpu_memorywrite_w(paddr[1], (UINT16)(data >> 8));
		cpu_memorywrite(paddr[1] + 2, (UINT8)(data >> 24));
		break;

	case 2:
		cpu_memorywrite_w(paddr[0], (UINT16)data);
		cpu_memorywrite_w(paddr[1], (UINT16)(data >> 16));
		break;

	case 3:
		cpu_memorywrite(paddr[0], (UINT8)data);
		cpu_memorywrite_w(paddr[0] + 1, (UINT16)(data >> 8));
		cpu_memorywrite(paddr[1], (UINT8)(data >> 24));
		break;

	default:
		cpu_memorywrite_d(paddr[0], data);
		break;
	}
}


#if defined(USE_CPU_BULKREP)
UINT8 * MEMCALL
cpu_vmemory_get_direct_host_ptr(int idx, UINT32 offset, UINT leng, int ucrw)
{
	descriptor_t *sdp;
	UINT32 addr;

	__ASSERT((unsigned int)idx < CPU_SEGREG_NUM);
	__ASSERT(leng > 0);

	sdp = &CPU_STAT_SREG(idx);
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM) {
		return cpu_lmemory_get_direct_host_ptr(addr, leng, ucrw);
	}

	/*
	 * Non-faulting segment probe for REP bulk fast paths.
	 * If the descriptor has not already been validated for the whole
	 * address space, fall back to the old one-element path so that segment
	 * limit exceptions occur at exactly the normal instruction point.
	 */
	if (!SEG_IS_VALID(sdp) || !SEG_IS_PRESENT(sdp) || SEG_IS_SYSTEM(sdp)) {
		return NULL;
	}
	if ((ucrw & CPU_PAGE_WRITE) != 0) {
		if (SEG_IS_CODE(sdp) ||
		    (SEG_IS_DATA(sdp) && !SEG_IS_WRITABLE_DATA(sdp)) ||
		    !(sdp->flag & CPU_DESC_FLAG_WRITABLE)) {
			return NULL;
		}
	} else {
		if ((SEG_IS_CODE(sdp) && !SEG_IS_READABLE_CODE(sdp)) ||
		    !(sdp->flag & CPU_DESC_FLAG_READABLE)) {
			return NULL;
		}
	}
	if (!(sdp->flag & CPU_DESC_FLAG_WHOLEADR)) {
		return NULL;
	}
	return cpu_lmemory_get_direct_host_ptr(addr, leng, ucrw);
}
#endif


DECLARE_VIRTUAL_ADDRESS_MEMORY_RW_FUNCTIONS(b, UINT8, 1)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RMW_FUNCTIONS(b, UINT8, 1)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RW_FUNCTIONS(w, UINT16, 2)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RMW_FUNCTIONS(w, UINT16, 2)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RW_FUNCTIONS(d, UINT32, 4)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RMW_FUNCTIONS(d, UINT32, 4)
DECLARE_VIRTUAL_ADDRESS_MEMORY_RW_FUNCTIONS(q, UINT64, 8)

REG80 MEMCALL
cpu_vmemoryread_f(int idx, UINT32 offset)
{
	descriptor_t *sdp;
	UINT32 addr;
	int exc;

	__ASSERT((unsigned int)idx < CPU_SEGREG_NUM);

	sdp = &CPU_STAT_SREG(idx);
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM)
		return cpu_memoryread_f(addr);

	if (!SEG_IS_VALID(sdp)) {
		exc = GP_EXCEPTION;
		goto err;
	}
	if (!(sdp->flag & CPU_DESC_FLAG_READABLE)) {
		cpu_memoryread_check(sdp, offset, 10, CHOOSE_EXCEPTION(idx));
	} else if (!(sdp->flag & CPU_DESC_FLAG_WHOLEADR)) {
		if (!check_limit_upstairs(sdp, offset, 10, SEG_IS_32BIT(sdp)))
			goto range_failure;
	} 
	return cpu_lmemoryread_f(addr, CPU_PAGE_READ_DATA | CPU_STAT_USER_MODE);

range_failure:
	VERBOSE(("cpu_vmemoryread_f: type = %d, offset = %08x, limit = %08x", sdp->type, offset, sdp->u.seg.limit));
	exc = CHOOSE_EXCEPTION(idx);
err:
	EXCEPTION(exc, 0);
	{
		REG80 dummy;
		memset(&dummy, 0, sizeof(dummy));
		return dummy;	/* compiler happy */
	}
}

void MEMCALL
cpu_vmemorywrite_f(int idx, UINT32 offset, const REG80 *value)
{
	descriptor_t *sdp;
	UINT32 addr;
	int exc;

	__ASSERT((unsigned int)idx < CPU_SEGREG_NUM);

	sdp = &CPU_STAT_SREG(idx);
	addr = sdp->u.seg.segbase + offset;

	if (!CPU_STAT_PM) {
		cpu_memorywrite_f(addr, value);
		return;
	}

	if (!SEG_IS_VALID(sdp)) {
		exc = GP_EXCEPTION;
		goto err;
	}
	if (!(sdp->flag & CPU_DESC_FLAG_WRITABLE)) {
		cpu_memorywrite_check(sdp, offset, 10, CHOOSE_EXCEPTION(idx));
	} else if (!(sdp->flag & CPU_DESC_FLAG_WHOLEADR)) {
		if (!check_limit_upstairs(sdp, offset, 10, SEG_IS_32BIT(sdp)))
			goto range_failure;
	}
	cpu_lmemorywrite_f(addr, value, CPU_PAGE_WRITE_DATA | CPU_STAT_USER_MODE);
	return;

range_failure:
	VERBOSE(("cpu_vmemorywrite_f: type = %d, offset = %08x, limit = %08x", sdp->type, offset, sdp->u.seg.limit));
	exc = CHOOSE_EXCEPTION(idx);
err:
	EXCEPTION(exc, 0);
}
